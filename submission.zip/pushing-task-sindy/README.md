# pushing-task-sindy

## Command to run demo:  
1. To install required python libraries  
`bash install.sh`  
2. Run demo  
`python demo.py`

The results will be saved in `demo.gif`.