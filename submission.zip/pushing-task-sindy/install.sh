pip install gym
pip install tqdm
pip install control
pip install Pillow
pip install numpngw